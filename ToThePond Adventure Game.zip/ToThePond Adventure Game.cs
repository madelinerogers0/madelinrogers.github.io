﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//help with the inventory code by the tutors Grace and Mack
//help with debugging, adding reset values, and both ending achiement methods by Grace Anders
//madlib code inspired by Janell Baxter

namespace ToThePond
{

    public class Game
    {
        Item item = new Item();
        

        public static string CharacterName = "John Doe";
        //static int frogpoint = 0;
        public  List<Item> Inventory = new List<Item>();


        public Game()
        {
            StartGame();
        }

        public  void StartGame()
        {
            item.frogpoint = 0;

            Console.WriteLine("To the Pond!");
            Console.WriteLine("Welcome to To the Pond. You are now a frog trying to find the way to the pond before winter comes...hopefully");
            NameCharacter();
            MakeFrog();
            Frog playerfrog = new Frog();
            Choice1();
            OpeningDialogue();
            Choice2();
            Choice3();
            Choice4();
            Choice5();
        }
        public void NameCharacter()
        {
            Console.WriteLine("What would you like to name your character?");
            CharacterName = Console.ReadLine();

            Console.WriteLine("Great! Your character is now named " + CharacterName);
        }

        public void MakeFrog()
        {
            string frog = @"

               _________________
          ____ '               '____
         ( 0  |                |0   )
         ( __ /                \__ _)
         (         \____/           )
           |                        |
           |       ________         |
          _|      /        \        |_
         (       |          |         )
         (     ) _|________|____(     )
          \   /                  \    /
         /__|___\                /__|_ _\
         \/ \/  \/               \/ \/ \/
        ";
          Console.WriteLine(frog);
        }

        
        private void Choice1()
        {
            string input = "";
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.WriteLine(CharacterName + " frog, are you ready to embark on your journey to the pond? Press A for yes or B for no.");
            input = Console.ReadLine();
            input = input.ToUpper();
            if (input == "A")
            {
                Console.WriteLine("Alright. Let's get started. Goodluck and hop on.");


                Utils.PressEnter();
            }
            else
            {
                Console.WriteLine(CharacterName + " frog has succumbed to the cold cold winter...");
                return;
            }
            Console.Clear();
            

        }
        public void OpeningDialogue()
        {
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.WriteLine("The timid yellow sun rises slowly above the clouds and peeks through the trees to \nilluminate the hazy woods.");
            Console.WriteLine("You blink your froggy little eyes and slowly wake up inside your humble log.");
            Console.WriteLine("As you look around you realize that little frog is nowhere to been seen...");

            Utils.PressEnter();

        }
        private void Choice2()
        {
            string input = "";
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.WriteLine("Press A to go look for little frog. Press B to wait inside.");
            input = Console.ReadLine();
            input = input.ToUpper();
            if (input == "A")
            {
                Console.Clear();
                Console.WriteLine("You hop out of the log and see little frog playing in the fallen and slightly damp leaves.");
                item.frogpoint++;

                Utils.PressEnter();
            }
            else
            {
                Console.WriteLine("After waiting a bit, little frog hops into the log a slightly damp for a reason you don't know.");

                Utils.PressEnter();
            }

            
        }
        private void Choice3()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\nlittle frog: oh hey, " + CharacterName + " frog. What's up?");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.WriteLine("\nPress A to reply \"it's getting cold. we should go.\". Press B to reply \"are you ready to leave?\"");
            string input = Console.ReadLine();
            input = input.ToUpper();

            if (input == "A" || input == "B")
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("little frog: can't you get it through your membrane? i'm not going!");
                item.frogpoint++;

                Utils.PressEnter();

            }
        }

        private void Choice4()
        {
            string input2 = "";
            Console.WriteLine("\n Press A to reply \"don't be such a brat.\". Press B to reply \"why are you so against going?\"");
            input2 = Console.ReadLine();
            input2 = input2.ToUpper();

            if (input2 == "A")
            {
                Console.Clear();
                Console.WriteLine("little frog: hey! don't be a meanie! i just don't see a point in going we're nice and safe here. it's been that way for so long");
                item.frogpoint--;

                Utils.PressEnter();

            }
            else
            {
                Console.Clear();
                Console.WriteLine("little frog:  i just don't see a point in going we're nice and safe here. it's been that way for so long");
                item.frogpoint++;
               
                //the frog points are supposed to be accumulating and lead to the good ending but for some reason it's not happening
                Utils.PressEnter();

            }

        }

        private void Choice5()
        {
            Console.WriteLine(item.frogpoint);
            Utils.PressEnter();
            //this was written to attempt to find out where the error(s) appear(s) but visual studios won't write it out

            Console.WriteLine($"\nYou have recieved {item.frogpoint} points Press A to reply \"Well, parent frog told me the cold is coming so we need to find the pond right away.\"  Press B to reply \"Can't you just listen to me for once?\".");
            item.frogpoint++;

            string input3 = Console.ReadLine();
            if (input3.ToLower() == "a" && item.frogpoint == 4)
            {
                Console.Clear();
                Console.WriteLine("little frog: *sigh* i miss parent frog " + CharacterName + " frog...");
                Console.WriteLine("little frog: alright i'll go.");
                Lude();


            }
            else
            {
                item.frogpoint--;
                Console.Clear();
                Console.WriteLine("little frog: no way! forget about it i'm not going!");
                Utils.PressEnter();
                BadLude();

            }
        }
        public void BadLude()
        {
            Utils.BadEndingAchieved = true;
            Console.WriteLine("Unsucsessfully convincing little frog, " + (Game.CharacterName) + "frog hopped on hesitantly to the pond.");
            Console.WriteLine("\npit pat pit pat the frog feet frolicked through the forest.");
            Console.WriteLine("*grumble grumble*");
            Console.WriteLine("you notice you are getting hungry...time to find some grub. (or in this case, flies)");
            FoodGame.FindFood();

            Encounter.Intro();

            
            Ending();
        }
        public void Lude()
        {
            Utils.GoodEndingAchieved = true;
            Console.ReadKey();

            Console.WriteLine("Having sucsessfully convinced little frog, " + (Game.CharacterName) + "frog and little frog hopped on their merry way to the pond.");
            Console.WriteLine("\npit pat pit pat the frog feet frolicked through the forest.");
            Console.WriteLine("*grumble grumble*");
            Console.WriteLine("little frog: " + (Game.CharacterName) + " frog. I'm hungry !! isn't it dinner time yet ??");
            Console.WriteLine("you notice you are getting hungry...time to find some grub. (or in this case, flies)");
            FoodGame.FindFood();
            Console.WriteLine("little frog: hey! gimme some !!");

//Encounter BirdTime = new Encounter();

            Encounter.Intro();
            Encounter.BirdInteraction();
            Encounter.Interact2();
            WhichPreface();
            FrogStory.BuildStory();
            Ending();
        }

        public void WhichPreface()
        {
            Console.WriteLine(item.frogpoint.ToString());
            Utils.PressEnter();

            if (Utils.BadEndingAchieved == true)

            {
                FrogStory.BadPreface();
            }
            else
            {
                FrogStory.Preface();

            }
        }

        public void Ending()
        {

          
            Inventory.Add(item);
            for(int i = 0; i < Inventory.Count; i++)
            {
                Console.WriteLine(Inventory[i].frogpoint + Inventory[i].flyhold);
                Console.WriteLine($"You recieved {Inventory[i].frogpoint} points and got {Inventory[i].flyhold} flys" );
                Utils.PressEnter();
            }

            //if (Utils.GoodEndingAchieved == true && Utils.BadEndingAchieved == true)
            //{
            //    Console.WriteLine("You have gotten both endings!");
            //}
            Console.WriteLine(item.frogpoint.ToString());
            Utils.PressEnter();
            if (item.frogpoint == 4)
            {
                GoodEnding();
            }
            else
            {
                BadEnding();
            }


          


        }

        //public void CheckEnding()
        //{
        //    if (Utils.GoodEndingAchieved == true && Utils.BadEndingAchieved == true)
        //    {
        //        Console.WriteLine("You have gotten both endings!");
        //    }
        //    else if (Utils.GoodEndingAchieved == true && Utils.BadEndingAchieved != true)
        //    {
        //        GoodEnding();
        //    }
        //    else
        //    {
        //        BadEnding();
        //    }
        //}

        public void GoodEnding()
        {

            Console.WriteLine("after being thoruoghly entertained, little frog was quiet for the rest of the trip and this made you happy.");
            Console.WriteLine("\n however, it wasn't long before you realized that you had no idea where you were.");
            Console.WriteLine("\nis everything okay, " + Game.CharacterName + "frog?");
            Console.WriteLine("\nyou stand still unsure of what to stay.");
            Console.WriteLine(".......");
            Utils.PressEnter();
            Console.Clear();

            Console.WriteLine("suddenly you see something swoop down infront of you");
            Console.WriteLine("\n it's the bird from earlier !");
            Console.WriteLine("\n she seems to be trying to tell you something.");
            Console.WriteLine("\n little frog: let's follow her !");
            Utils.PressEnter();
            Console.Clear();

            Console.WriteLine("so the two of you follow her to the left, to the right, through a bush, under roots and then...");
            Console.WriteLine("\n there it is: the pond");
            Utils.PressEnter();

            Replay();
        }

        public void BadEnding()
        {


            Console.WriteLine("\n it wasn't long before you realized that you had no idea where you were.");
            Console.WriteLine("\nis everything okay, " + Game.CharacterName + "frog?");
            Console.WriteLine("\nyou stand still unsure of what to stay.");
            Console.WriteLine(".......");
            Utils.PressEnter();
            Console.Clear();

            Console.WriteLine("suddenly you see something swoop down infront of you");
            Console.WriteLine("\n it's the bird from earlier !");
            Console.WriteLine("\n she seems to be trying to tell you something but you don't understand.");
            Console.WriteLine("..........");
            Console.WriteLine("unable to find the pond," + Game.CharacterName + " frog succumbed to the cold cold winter");
            Utils.PressEnter();
            Console.Clear();

            Replay();
        }

        public void Replay()
        {
            Console.WriteLine("Lets replay the game");
            Utils.PressEnter();
            item.frogpoint = 0;
            item.flyhold = 0;

            StartGame();
            
        }
    }
    
}

