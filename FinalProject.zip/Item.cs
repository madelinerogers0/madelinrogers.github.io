﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject
{
   public class Item
    {
        public string itemName;
        public string itemDescription;

        //create an overloaded constructor with two input parameters

        public Item(string _itemName, string _itemDescription)
        {
            //marry the input parameters with our vars
            this.itemName = _itemName;
            this.itemDescription = _itemDescription;
        }
    }
}
