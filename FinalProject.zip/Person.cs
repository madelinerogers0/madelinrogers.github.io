﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;

namespace FinalProject
{
    public class Person
    {

        public string name = "Anonymous Player";
        public string  PlayerAvatar = "Images/whitewings.jpg";
        public List<Item> Inventory = new List<Item>();
        public List<vegetable> inventory = new List<vegetable>();
        public List<Potions> PotionInventory = new List<Potions>();

        public int dreamPoints;
        public int score;
        public string wingColor = "choose color";

       public Person()
        { Inventory.Add(new Item("Food Ration", "One Day of Food"));

            //set default HUD values
           
            this.dreamPoints = 100;
            this.score = 0;
            //this.wingColor;
        }

        //npc constructor
        public Person(string _name)
        {
            this.name = _name;

        }

       

        //public  SetPlayerImage()
        //{
        //    if (PlayerAvatarImage.Contains("g"))
        //    {
        //        PlayerAvatarImage = "Images/graywings.jpg";
        //    }
        //    if (PlayerAvatarImage.Contains("b"))
        //    {
        //        PlayerAvatarImage = "Images/blackwings.jpg";
        //    }
        //    if (PlayerAvatarImage.Contains("w"))
        //    {
        //        PlayerAvatarImage = "Images/whitewings.jpg";
        //    }

            
        //}

        //public BitmapImage ShowPlayerImage()
        //{
        //    return new BitmapImage(new Uri(PlayerAvatar, UriKind.Relative));
        //}

        public string ShowInventory()
        {
            //var to hold our list of inventory prior to return
             string output = "Inventory: \n";

            //foreach loop to read through each element in the inventory list

            foreach (Item i in Inventory)
            {
                output += i.itemName + "\n";
                
            }

            return output;


            


        }


        public string ShowPotionInventory()
        {
            string output = "potion inventory: \n";

            foreach(Potions p in PotionInventory)
            { 
                output += p.potionName + "\n";
            }
            return output;
        }

        public string Showinventory()
        {
            string output = "veggie inventory: \n";

            foreach (vegetable v in inventory)
            {
                output += v.veggieName + "\n";
                
            }
            return output;
        }
        public string ShowPlayerHUDInformation()
        {

            return $"Dream Points:{this.dreamPoints}\nScore: {this.score}\nWing Color: {this.wingColor}";

        }


    }
}
