﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject
{
    public class NPC : Person
    {
        public string profession;

        public NPC(string _name, string _profession)
        {
            this.name = _name;
            this.profession = _profession;
        }
    }
}
