﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FinalProject
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Item currentItem = new Item("", "");

        

        vegetable currentVeggie = new vegetable("", "");

        Potions currentPotion = new Potions("", "");

        List<Location> locations = new List<Location>();

        //create a var for current location
        Location currentLocation;


        Random randomNumber = new Random();

        Person player = new Person("");

        NPC npc1 = new NPC("Miss Witch", "Witch");

        bool MissWitchEncounter = false;

        NPC npc2 = new NPC("Humphrey", "Chef");
        
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Start()
        {
            
            SetUpLocations();
            ChooseAvatar();
            SetPlayerImage();
            ShowLocationsMenu();
            Travel();
            UpdatePlayerInformation();
        }

        private void SetUpLocations()
        {
            //set up locations

            locations.Add(new Location("HQ", "a very bright area", "Images/HQ.jpg"));

            locations.Add(new Location("One", "you find a bright meadow with lots of flowers", "Images/meadow.jpg"));

            locations.Add(new Location("Market", "it's a bustling marketplace", "Images/marketplace.jpg",

                new List<Item>
                {
                    new Item ("jar of bumblebees", "a jar of bumble bees. they don't seem too mad...yet"),
                    new Item ("bottle of frogs", "how do they all fit in there?")

                },

               new List<vegetable>
               {
                 new vegetable("rutabaga", "yellow on the inside"),
                 new vegetable("turnip", "white on the inside"),

               },

               new List<Potions>
               {
                    new Potions("fragrant of rose", "a potion-it smells a lot like flowers"),
                    new Potions("fragrant of honey", "a potion-it smells a lot like fresh honey"),
                    new Potions ("fragrant of pond", "a potion-it smells a lot like a fish pond..ew"),

               }

            ));

            locations.Add(new Location("Two", "a messy kitchen...is anyone here?", "Images/kitchen.jpg",
                new List<Item>
                {
                    new Item("wooden spoon", "you could stir something with this if you want"),
                    new Item("dish", "it has a little smudge on it"),
                    new Item ("mouse trap", "it's a little unsettling to find this here")
                }
                ));

            locations.Add(new Location("Three", "you see a painter is painting in his studio.", "Images/art studio.jpg",
                new List<Item>
                {
                     new Item("paintbrush","used to paint a picture"),
                     new Item ("paint blob","a strange but fascinating color"),
                     new Item("palette","used to mix colors")
                }

                ));

            locations.Add(new Location("Four", "you see a shepherd trying to separate his flock.","Images/shepherd.jpg",
                new List<Item>
                {
                            new Item("shears","used to shear a sheep"),
                            new Item ("crook","used for herding sheep"),
                            new Item("feed","a snack for the sheep")
                }

                ));

            locations.Add(new Location("Five", "you find yourself in the presence of a small marching band.", "Images/marching band.jpg",
                new List<Item>
                {
                 new Item("trumpet", "it makes a loud sound"),
                 new Item ("baton", "if you use it, make sure you can conduct"),
                 new Item("melody","it sounds so sweet(ish)")
                 }
            ));

            currentLocation = locations[0];
        }

      

        private void ChooseAvatar()
        {

            customizePlayerTextBox.Text = "";
            PlayerHUDTextBlock.Text = player.wingColor;
            


        }

        private void SetPlayerImage()
        {

            PlayerAvatarImage.Source = new BitmapImage(new Uri("graywings.jpg", UriKind.Relative));


        }

        void chooseButton_Click(object sender, RoutedEventArgs e)
        {

            if (customizePlayerTextBox.Text.ToLower().Contains("b"))
            {
                player.wingColor = "black";
                player.PlayerAvatar = "Images/blackwings.jpg";


            }       

            else if (customizePlayerTextBox.Text.ToLower().Contains("w"))
            {
                player.wingColor = "white";
                player.PlayerAvatar = "Images/whitewings.jpg";
            }

            else if (customizePlayerTextBox.Text.ToLower().Contains("g"))
            {
                player.wingColor = "gray";

            }
            else
            {
                NarrativeTextBox.Text = $"please pick the color of your wings";
            }

            
            UpdatePlayerInformation();
            ShowLocationsMenu();
            Travel();
            

        }

     


        private void ShowLocationsMenu()
        {
            //populate the textblock in the window with the 
            //possible locations
            string temp = "";
            foreach (Location l in locations)
            {
                temp += l.Name + "\n";
            }
            LocationMenu.Text = temp;

        }

        private void UpdatePlayerInformation()
        {
            //create code block to publish
            //player name in playerNameInfo Label

            customizePlayerTextBlock.Text = $"choose your avatar's wing color: black, white or gray ";

          

            playerNameLabel.Content = player.name;



            //update inventory 
            

            PlayerInventoryTextBlock.Text = player.ShowInventory();

            playerVeggieInventoryTextBlock.Text = player.Showinventory();

            PlayerPotionInventoryTextBlock.Text = player.ShowPotionInventory();

            //upidate playerHUD Information
            PlayerHUDTextBlock.Text = player.ShowPlayerHUDInformation();
        }
        private void Travel()
        {
            LocationName.Text = currentLocation.Name;
            LocationDescription.Text = currentLocation.Description;
            LocationImage.Source = currentLocation.ShowBitMapImage();

            TravelLocationTextBox.Text = "";

            //update player info upon Travel


            //update location specific narrative upon travel
            LocationSpecificNarrative();

            UpdatePlayerInformation();

        }

      
        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            Start();
        }

        private void TravelButton_Click(object sender, RoutedEventArgs e)
        {
            string locationEntered = TravelLocationTextBox.Text;
            locationEntered = locationEntered.ToLower();
            //did they enter something in the textbox
            if (locationEntered != "")
            {
                //look for location in location list
                foreach (Location l in locations)
                {
                    if (l.Name.ToLower().Contains(locationEntered))
                    {
                        //then travel to location
                        currentLocation = l;
                    }
                }

                Travel();

                UpdatePlayerInformation();

                CheckMissWitchEncounterTrue();

                CheckRutabaga();

            }
        }

        
        private void LocationSpecificNarrative()
        {

            if (currentLocation.itemsList.Count > 0)
            {
                currentItem = currentLocation.itemsList[GetRandomNumber(currentLocation.itemsList.Count)];


                NarrativeTextBox.Text = $"You have found a/an {currentItem.itemName} ({currentItem.itemDescription}). \nType yes if you wish to add the item to your inventory.";
                

            }

            else if (currentLocation.vegetableList.Count > 0)
            {
                currentVeggie = currentLocation.vegetableList[GetRandomNumber(currentLocation.vegetableList.Count)];
                NarrativeTextBox.Text = $"You have found a/an {currentVeggie.veggieName} ({currentVeggie.veggieDescription}). \nType yes if you wish to add the item to your inventory.";

            }
            
            else if (currentLocation.potionList.Count > 0)
            {
                currentPotion = currentLocation.potionList[GetRandomNumber(currentLocation.potionList.Count)];
                NarrativeTextBox.Text = $"You have found a/an {currentPotion.potionName} ({currentPotion.potionDescription}). \nType yes if you wish to add the item to your inventory.";

            }


            else
            {
                NarrativeTextBox.Text = "There are no more items in this location. Time to travel onto the next location.";
            }


        }

      

        //create method to return new random number value
        private int GetRandomNumber(int _max)
        {
            return randomNumber.Next(_max);
        }

        private void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            string Answer = ResponseTextBox.Text;
            Answer = Answer.ToLower();

            if (Answer.Contains("y"))
            {
                //if so, add item to inventory
                player.Inventory.Add(currentItem);
                currentLocation.itemsList.Remove(currentItem);
            }
            if (Answer.Contains("y"))
            {
                player.inventory.Add(currentVeggie);

                currentLocation.vegetableList.Remove(currentVeggie);
            }
            if (Answer.Contains("y"))
            {

                player.PotionInventory.Add(currentPotion);
                currentLocation.potionList.Remove(currentPotion);
            }
           

            ResponseTextBox.Text = "";

            //travel after button click
            Travel();

            //check for key items
            CheckForKeyItems();

            //update the HUD
            player.ShowPlayerHUDInformation();
        }

        private void CheckForKeyItems()
        {
            if (MissWitchEncounter == false && PlayerPotionInventoryTextBlock.Text.Contains("fragrant of rose") && PlayerPotionInventoryTextBlock.Text.Contains("fragrant of honey") && PlayerPotionInventoryTextBlock.Text.Contains("fragrant of pond") && PlayerInventoryTextBlock.Text.Contains("jar of bumblebees"))
            {
                //grant player score points
                player.score += 100;

                //witch encounter
                NarrativeTextBox.Text = $"You have encountered {npc1.name}! They wish to give you the gift of dream points and a message: Return to the Second Dream and find the Chef.";

                //witch gives karma points
                player.dreamPoints += 1000;

                //witch encounter var set to true
                MissWitchEncounter = true;

            }



        }
        //method to check for cave dweller encounter
        private void CheckMissWitchEncounterTrue()
        {
            if (MissWitchEncounter && currentLocation.Name.Contains("Two"))
            {
                NarrativeTextBox.Text = $"You have encountered  {npc2.name} the chef in the kitchen. He asks if you have a rutabaga. Do you wish to offer it to him in trade? Enter Yes, if so.";
            }

            else
            {
                LocationSpecificNarrative();
            }
        }

        //create blessed water check method
        private void CheckRutabaga()
        {
            //if location is Town
            if (LocationName.Text == "Two" && MissWitchEncounter)
            {
                if (playerVeggieInventoryTextBlock.Text.Contains("rutabaga"))

                {
                    NarrativeTextBox.Text = $"The {npc2.name} sees that you have a rutabaga in your possesion and offer to trade you some of his stew. A declicious food you've been hungry for this whole time.";

                    Item specialItem = new Item("stew", "a delicious meal");

                    player.Inventory.Insert(0, specialItem);

                    player.ShowInventory();
                }

                else
                {
                    NarrativeTextBox.Text = $"You encounter the {npc2.name} in the kitchen. You do not have the item the {npc2.name} is looking for. Return to the market to find the rutabaga.";
                }

            }

            else
            {
                LocationSpecificNarrative();
            }

        }

        
    }



}

//        }
//    }
//}
