﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;

namespace FinalProject
{
    //indoor outdoor
    //underwater onland
    //outerspace ??
    class Location
    {
        public string Name;
        public string Description;

        public string locationPath = "Images/HQ.jpg";

        public List<Item> itemsList = new List<Item>();
        public List<vegetable> vegetableList = new List<vegetable>();
        public List<Potions> potionList = new List<Potions>();

        public Location()
        {
        }
        public Location(string _name, string _description)
        {
            this.Name = _name;
            this.Description = _description;
        }
        public Location(string _name, string _description, string _locationpath)
        {
            //marry the parameters to the vars
            this.Name = _name;
            this.Description = _description;
            this.locationPath = _locationpath;
        }

        public Location(string _name, string _description, string _locationpath, List<Item> _itemsList)
        {
            this.Name = _name;
            this.Description = _description;
            this.locationPath= _locationpath;
            this.itemsList = _itemsList;
        }

        public Location(string _name, string _description, string _locationpath, List<Item> _itemsList, List<vegetable> _vegetableList)
        {
            this.Name = _name;
            this.Description = _description;
            this.locationPath = _locationpath;  
            this.itemsList = _itemsList;
            this.vegetableList = _vegetableList;
        }

        public Location(string _name, string _description, string _locationpath, List<Item> _itemsList, List<vegetable> _vegetableList, 
            List<Potions> _potionList)
        {
            this.Name = _name;
            this.Description = _description;
            this.locationPath = _locationpath;
            this.itemsList = _itemsList;
            this.vegetableList = _vegetableList;
            this.potionList = _potionList;
        }
        public BitmapImage ShowBitMapImage()
        {
            return new BitmapImage(new Uri(locationPath, UriKind.Relative));
        }
    }

   



}
