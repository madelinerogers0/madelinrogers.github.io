﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject
{
    public class Potions
    {
        public string potionName;
        public  string potionDescription;
        public Potions(string _potionName, string _potionDescription)
        {
            //marry the input parameters with our vars
            this.potionName = _potionName;
            this.potionDescription = _potionDescription;
        }
    }
}
