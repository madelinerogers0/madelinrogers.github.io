﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject
{
    public class vegetable
    {
        public string color;
        public string veggieName;
        public string veggieDescription;

        public   vegetable(string _veggieName, string _veggieDescription)
        {
            this.veggieName = _veggieName;
            this.veggieDescription = _veggieDescription;
        }
        //public void Cut()
        //{

        //}

    }
}
